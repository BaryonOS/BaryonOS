from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import subprocess

root = Path('/workspace/baryon-h02-completion')
out = root / 'build/issue274-ui-audit-d16fa086'
out.mkdir(parents=True, exist_ok=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == 'd16fa0862a42d83f7de7fda8dd2de54357d3e533'
groups = {
    'native_ui': ['ui/native/src'],
    'design_prototype_and_consumers': ['ui/design'],
    'legacy_browser_prototype': ['ui/prototype'],
    'sdk_application_sources': [':(glob)sdk/examples/*/src/**'],
    'userspace_diagnostics_and_probes': ['userspace'],
    'boot_loader_diagnostics': ['boot/loader/src'],
    'boot_kernel_entry_serial': ['kernel/src/main.rs', 'kernel/src/serial.rs'],
}
suffixes = {'.rs', '.S', '.js', '.jsx', '.mjs', '.ts', '.tsx', '.html'}
files = []
literals = []
locales = []
# This is a bounded lexical inventory, not an AST or a proof of language.
rust = re.compile(r'//[^\n]*|/\*.*?\*/|b?\x27(?:\\.|[^\x27\\])\x27|(?:b?r(?P<hash>\#{0,8}))"(?P<raw>.*?)"(?P=hash)|(?P<str>b?"(?:\\.|[^"\\])*")', re.S)
js = re.compile(r'//[^\n]*|/\*.*?\*/|(?P<str>"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27|`(?:\\.|[^`\\])*`)', re.S)
nl = re.compile(r'\b(?:simulatie|besturingssysteem|geen|opnieuw|afsluiten|sluiten|opslaan|openen|nieuw|nieuwe|bestand|bestanden|notitie|notities|verwijderen|machtiging|toegang|delen|instellingen|apparaat|apparaten|wachtwoord|pincode|aanmelden|afmelden|vergrendelen|ontgrendelen|toegankelijkheid|zoeken|gevonden|beveiliging|gebruiker|geopend|bureaublad|rekenmachine|verbinding|verbinden|ontvangen|aanbieden|ruimte|verbruik|beschikbaar|wijzigingen|fout|mislukt|annuleren|doorgaan|bevestigen|weigeren|toestaan|versleuteling|herstel|onbekend|ontbreekt|lezen|schrijven|gedeeld|volgende|vorige|terug|welkom|geladen|opgeslagen|vastzetten|losmaken|gewijzigd|herstellen|bewaren|hernoemen|verplaatsen|kopie|klaar|verborgen|wissen|wachten|scherm|venster|vensters|weergave|aangepast|geselecteerd|selecteren|alleen|deze|wordt|heeft|zijn|kunt|kiest|voor|met|zonder|nog|niet|wel|uw|jouw|je)\b', re.I)

def add(path, text, line, value, kind):
    value = value.strip()
    if value and re.search(r'[A-Za-zÀ-ÿ]', value):
        literals.append({'path': path, 'line': line, 'kind': kind, 'value': value,
                         'dutch_lexical_candidate': bool(nl.search(value))})

def javascript(path, text, offset=0):
    for match in js.finditer(text):
        value = match.groupdict().get('str')
        if value is not None:
            add(path,text,offset+text.count('\n',0,match.start())+1,value[1:-1],'js_literal_or_template')
    # Concept pages contain inline Babel/JSX rather than .jsx files.
    for match in re.finditer(r'>([^<>{]+)<',text):
        add(path,text,offset+text.count('\n',0,match.start())+1,re.sub(r'\s+',' ',match.group(1)),'jsx_text_candidate')

class Visible(HTMLParser):
    def __init__(self, path):
        super().__init__(convert_charrefs=True)
        self.path = path
        self.hidden = 0
        self.script = False
    def handle_starttag(self, tag, attrs):
        if tag in {'script', 'style'}:
            self.hidden += 1
            self.script = tag == 'script'
        for key, value in attrs:
            if value is not None and key in {'title','alt','placeholder','aria-label','lang'}:
                add(self.path, '', self.getpos()[0], value, 'html_'+key)
    def handle_endtag(self, tag):
        if tag in {'script', 'style'} and self.hidden:
            self.hidden -= 1
            self.script = False
    def handle_data(self, data):
        if not self.hidden:
            add(self.path, '', self.getpos()[0], re.sub(r'\s+', ' ', data), 'html_text')
        elif self.script:
            javascript(self.path,data,self.getpos()[0]-1)

for group, paths in groups.items():
    raw = subprocess.check_output(['git', 'ls-files', '-z', '--', *paths], cwd=root)
    names = [n.decode('utf-8', 'strict') for n in raw.split(b'\0') if n]
    for name in names:
        p = root / name
        if p.suffix not in suffixes:
            continue
        # Exclude explicit test paths; these are not public string producers.
        if '/tests/' in name or '/node_modules/' in name:
            continue
        assert not p.is_symlink() and p.is_file()
        blob = subprocess.check_output(['git', 'show', head+':'+name], cwd=root)
        assert blob == p.read_bytes()
        text = blob.decode('utf-8','strict')
        files.append({'path': name, 'group': group, 'bytes': len(blob), 'sha256': hashlib.sha256(blob).hexdigest()})
        if p.suffix == '.html':
            parser = Visible(name)
            parser.feed(text)
        else:
            parser = rust if p.suffix in {'.rs', '.S'} else js
            test_lines = []
            if p.suffix == '.rs':
                masked = rust.sub(lambda m: re.sub(r'[^\n]', ' ', m.group(0)), text)
                for module in re.finditer(r'#\[cfg\(test\)\]\s*(?:#\[[^\]]+\]\s*)*mod\s+\w+\s*\{',masked):
                    depth = 1
                    end = module.end()
                    while end < len(masked) and depth:
                        depth += (masked[end] == '{') - (masked[end] == '}')
                        end += 1
                    test_lines.append((text.count('\n',0,module.start())+1,text.count('\n',0,end)+1))
            for match in parser.finditer(text):
                value = match.groupdict().get('raw')
                if value is None:
                    value = match.groupdict().get('str')
                    if value is None:
                        continue
                    value = value[2:-1] if value.startswith('b"') else value[1:-1]
                line = text.count('\n',0,match.start())+1
                kind = 'rust_inline_test_literal' if any(lo <= line <= hi for lo,hi in test_lines) else 'rust_literal'
                add(name, text, line, value, kind if p.suffix=='.rs' else 'assembly_source_literal' if p.suffix=='.S' else 'js_literal_or_template')
            if p.suffix in {'.jsx','.tsx'}:
                for match in re.finditer(r'>([^<>{]+)<',text):
                    add(name,text,text.count('\n',0,match.start())+1,re.sub(r'\s+',' ',match.group(1)),'jsx_text_candidate')
        for number, line in enumerate(text.splitlines(),1):
            if re.search(r'\b(?:i18n|locale|localisation|localization|Intl|language|lang|translate|translations)\b',line,re.I):
                locales.append({'path':name,'line':number,'text':line.strip()})

manifest = {'source_commit':head,'path_enumeration':'git ls-files -z with explicit finite pathspecs; UTF-8 strict; current bytes equal exact HEAD blobs',
            'groups':groups,'suffixes':sorted(suffixes),'files':files,
            'limits':['Lexical candidates require manual contextual classification.','No source, UI, HTML, JavaScript or Markdown was changed.','Tests, binary assets, CSS and generated font data are excluded.','This does not prove complete OS localisation or dynamic user-content language.']}
(out/'scope.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
(out/'literal-candidates.json').write_text(json.dumps(literals,indent=2,ensure_ascii=False)+'\n')
(out/'locale-candidates.json').write_text(json.dumps(locales,indent=2,ensure_ascii=False)+'\n')
summary = {'files':len(files),'by_group':{g:sum(f['group']==g for f in files) for g in groups},
           'literal_candidates':len(literals),'dutch_lexical_candidates':sum(v['dutch_lexical_candidate'] for v in literals),
           'dutch_by_file':{p:sum(v['dutch_lexical_candidate'] and v['path']==p for v in literals) for p in sorted({v['path'] for v in literals if v['dutch_lexical_candidate']})},
           'locale_candidate_lines':len(locales)}
(out/'lexical-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary,indent=2,ensure_ascii=False))
