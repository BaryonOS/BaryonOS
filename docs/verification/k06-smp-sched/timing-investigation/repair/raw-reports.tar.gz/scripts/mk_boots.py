"""Build the per-boot evidence table of the K06 timing repair (diagnostic data)."""
import glob, json, os, re, sys
S, out = sys.argv[1], sys.argv[2]
H = f"{S}/hosted-43286858831"
COLS = ("series commit qemu host_cpus case boot passed failure duration_s timer_ratio ticks lost host extra "
        "span_us median_us own_median_us sync_ms sync_stall_ms scratch_ms lockpair_ms lock_max_ms").split()
KEYS = {"ed05150": ("wait_1360", "stall_1360", "wait_3934", "wait_4026"),
        "cc1043f": ("wait_1371", "stall_1371", "wait_4130", "wait_4222"),
        "67e592c": ("-", "-", "-", "-"), "c3c2890+": ("-", "-", "-", "-")}
def failure(error, bad):
    text = " ".join(bad or []) + " " + (error or "")
    for marker in ("SMP_CLOCK_DRIFT", "SMP:SCRATCH:TIMEOUT", "SMP:SYNC:TIMEOUT", "SMP:SYNC:STALLED",
                   "SMP:LOCK:STUCK", "SMP:LOCKPAIR:TIMEOUT"):
        if marker in text:
            return marker
    return (error or "").replace("\t", " ")[:60]
def row(series, commit, qemu, host, case, i, passed, fail, dur, ratio, edges, waits):
    sync, stall, scratch, pair = (waits.get(k, ["", ""])[0] for k in KEYS[commit])
    locks = [v[0] for k, v in waits.items() if k.startswith("lock_")]
    e = edges or [""] * 7
    return [series, commit, qemu, host, case, i, int(passed), "" if passed else fail, dur, ratio or "", *e,
            sync, stall, scratch, pair, max(locks) if locks else ""]
rows = []
for path in sorted(glob.glob(f"{S}/series/[ab]-*.json")):
    name = os.path.basename(path)[:-5]
    series, commit = ("local-A", "ed05150") if name.startswith("a-") else ("local-B", "cc1043f")
    data = json.load(open(path))
    for r in data["rows"]:
        if r["dur"] < 0 and not r["margins"] and not r["bad"] and r.get("error") is None:
            continue
        rows.append(row(series, commit, "8.2.2", data["hostcpus"], data["case"], r["i"], r["passed"],
                        failure(r.get("error"), r.get("bad")), r["dur"], r.get("ratio"), r.get("edges"), r["margins"]))
for path in sorted(glob.glob(f"{S}/ab/[AB]-*-*.json"), key=lambda p: (int(p.rsplit("-", 1)[1][:-5]), p)):
    arm = os.path.basename(path)[0]
    data = json.load(open(path))
    r = data["rows"][0]
    rows.append(row("local-AB", "67e592c" if arm == "A" else "c3c2890+", "8.2.2", data["hostcpus"], data["case"],
                    int(path.rsplit("-", 1)[1][:-5]), r["passed"], failure(r.get("error"), r.get("bad")),
                    r["dur"], r.get("ratio"), r.get("edges"), {}))
for case in ("four", "eight", "nine-capacity", "m3-load-two", "m3-load-eight"):
    base = f"{H}/{case}/x/build/k06-margin-{case}"
    report = json.load(open(f"{base}/diagnostic/margin-report.json"))
    ratios = {}
    for d in glob.glob(f"{base}/run/*/serial.txt"):
        m = re.search(r"-r([0-9]{3})-of-", d)
        for line in open(d, errors="replace"):
            if line.startswith("SMP:TIMER:RATIO:"):
                ratios[int(m[1])] = int(line.rsplit(":", 1)[1])
    for c in report["cases"]:
        o = c.get("observed") or {}
        e = o.get("clock_edges")
        edges = [e[k] for k in ("ticks", "lost", "host", "extra", "span_us", "median_us", "own_median_us")] if e else None
        rows.append(row("hosted-43286858831", "cc1043f", "10.2.1", "4 (runner)", case, c["iteration"], c["passed"],
                        failure(c.get("error"), None), round(c["host_watchdog"]["measured_s"], 2),
                        ratios.get(c["iteration"]), edges, o.get("guest_waits", {})))
with open(out, "w") as f:
    f.write("\t".join(COLS) + "\n")
    for r in rows:
        f.write("\t".join(str(v) for v in r) + "\n")
print(len(rows), "rows ->", out)
