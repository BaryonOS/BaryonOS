#!/bin/bash
# Interleaved A/B on the same host, one boot at a time (diagnostic, QEMU 8.2.2):
# A = base 67e592c (no margin records, no clock sampling), B = the final source.
# Order ABBA so slow host drift hits both arms alike. Usage: ab.sh <case> <pairs>
S=<scratch>
export NOS_QEMU_MACHINE=pc-q35-8.2
case=$1; pairs=$2
one() { # arm worktree index
  ( cd $2 && python3 -B $S/series2.py $case 0-3 1 $S/ab/$1-$case-$3.json >> $S/ab/$1-$case.log 2>&1; rm -rf build/run )
}
for i in $(seq 1 $pairs); do
  if [ $((i % 2)) = 1 ]; then one A $S/snap-67e592c $i; one B $S/edit $i; else one B $S/edit $i; one A $S/snap-67e592c $i; fi
done
python3 -I - $S/ab $case <<'PY'
import glob, json, sys
d, case = sys.argv[1], sys.argv[2]
for arm in "AB":
    rows = [json.load(open(p))["rows"][0] for p in sorted(glob.glob(f"{d}/{arm}-{case}-*.json"))]
    fails = {}
    for r in rows:
        if not r["passed"]:
            key = next((b for b in r["bad"] if "FAIL" in b), r["error"])
            fails[key] = fails.get(key, 0) + 1
    print(f"arm {arm} {case}: passed {sum(r['passed'] for r in rows)}/{len(rows)} fails {fails}")
PY
echo "ab done $case" >> $S/ab/done.txt
