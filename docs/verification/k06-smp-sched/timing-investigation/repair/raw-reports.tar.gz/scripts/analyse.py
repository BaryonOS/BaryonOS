#!/usr/bin/env python3
"""Summarise diagnostic series files (rows: passed, error, dur, bad, edges, ratio, margins)."""
import json, statistics as st, sys
NOMINAL = 999847
def pct(v): return (v - NOMINAL) * 100 / NOMINAL
def q(xs, p):
    xs = sorted(xs); return xs[min(len(xs) - 1, int(p * len(xs)))]
for path in sys.argv[1:]:
    d = json.load(open(path)); rows = d["rows"]
    n = len(rows); ok = sum(r["passed"] for r in rows)
    print(f"\n== {d['case']} host {d['hostcpus']}: {ok}/{n} passed; series_error={d.get('series_error')}")
    reasons = {}
    for r in rows:
        if not r["passed"]:
            key = (r["bad"][-1] if r["bad"] else (r.get("error") or "?"))[:70]
            if r.get("timed_out"): key = "HOST WATCHDOG " + key
            reasons[key] = reasons.get(key, 0) + 1
    for k, v in sorted(reasons.items(), key=lambda kv: -kv[1]): print(f"   fail x{v}: {k}")
    durs = [r["dur"] for r in rows if r["dur"] > 0]
    if durs: print(f"   duration s: median {st.median(durs):.1f} max {max(durs):.1f}")
    ratios = [r["ratio"] for r in rows if r.get("ratio")]
    if ratios: print(f"   TIMER:RATIO min {min(ratios)} max {max(ratios)} (band 50000..75000), n={len(ratios)}")
    e = [r["edges"] for r in rows if r.get("edges")]
    if e:
        lostp = [x[1] * 100 / x[0] for x in e]; hostshare = [x[2] / x[1] for x in e if x[1]]
        raw = [pct(x[5]) for x in e]; own = [pct(x[6]) for x in e]
        print(f"   clock n={len(e)}: lost% median {st.median(lostp):.2f} p90 {q(lostp,.9):.2f} max {max(lostp):.2f}; "
              f"host share min {min(hostshare, default=1):.3f}; boots with kernel-charged loss {sum(x[1] != x[2] for x in e)} "
              f"(max {max(x[1]-x[2] for x in e)}); extra>0 in {sum(x[3] > 0 for x in e)} (max {max(x[3] for x in e)})")
        print(f"   raw median dev%: min {min(raw):+.2f} median {st.median(raw):+.2f} max {max(raw):+.2f}; |raw|>1%: {sum(abs(v) > 1 for v in raw)}")
        print(f"   own median dev%: min {min(own):+.3f} median {st.median(own):+.3f} max {max(own):+.3f}; |own|>1%: {sum(abs(v) > 1 for v in own)}; |own|>0.5%: {sum(abs(v) > .5 for v in own)}")
        print(f"   span_us max {max(x[4] for x in e)} median {st.median(x[4] for x in e)}")
    worst = {}
    for r in rows:
        for k, (used, limit) in r["margins"].items():
            if limit and used / limit > worst.get(k, (0, 0, 0))[0]: worst[k] = (used / limit, used, limit)
    top = sorted(worst.items(), key=lambda kv: -kv[1][0])[:7]
    print("   worst margins: " + "; ".join(f"{k} {u}/{l} ({f:.0%})" for k, (f, u, l) in top))
