#!/usr/bin/env python3
"""Diagnostic only, not acceptance: run one SMP case N times on a host CPU set and
keep per boot: verdict, duration, margins and clock edge accounting parsed from the
serial text (so failed boots count too), and the failing lines."""
import json, os, re, sys
sys.path.insert(0, os.path.join(os.getcwd(), "tools"))
case, hostcpus, repeat, out = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
lo, hi = (hostcpus.split("-") + [hostcpus])[:2]
os.sched_setaffinity(0, set(range(int(lo), int(hi) + 1)))
import run_smp
if len(sys.argv) > 5:  # diagnostic watchdog so slow hosts show their tail instead of a kill
    run_smp.GUEST_TIMEOUT_S = int(sys.argv[5])
stdouts = []
real = run_smp.run_guest
def keep(*a, **k):
    guest = real(*a, **k)
    stdouts.append(guest["stdout"])
    return guest
run_smp.run_guest = keep
try:
    report = run_smp.run((case,), repeat=repeat)
except BaseException as exc:  # keep what was measured
    report = json.load(open(run_smp.BUILD / "smp-report.json"))
    report["series_error"] = repr(exc)
MARGIN = re.compile(r"SMP:MARGIN:(WAIT|STALL|LOCK|ROUND):([0-9]+):([0-9]+)/([0-9]+)")
EDGES = re.compile(r"SMP:CLOCK:EDGES:TICKS=([0-9]+):LOST=([0-9]+):HOST=([0-9]+):EXTRA=([0-9]+):SPAN_US=([0-9]+):US=([0-9]+):OWN_US=([0-9]+)")
rows = []
for item, text in zip(report["cases"], stdouts):
    lines = text.splitlines()
    bad = [l for l in lines if re.search(r"FAIL|TIMEOUT|STALLED|STUCK|DRIFT|STOPPED|QUARANTIN|OVERFLOW", l)
           and not l.startswith("SMP:CLOCK:SAMPLE")]
    edges = next((list(map(int, m.groups())) for m in map(EDGES.fullmatch, lines) if m), None)
    ratio = next((int(l.rsplit(":", 1)[1]) for l in lines if l.startswith("SMP:TIMER:RATIO:")), None)
    odd = [] if item["passed"] else [l for l in lines if not l.startswith(("SMP:SER:", "SMP:MARGIN:"))][-14:]
    rows.append({"i": item["iteration"], "passed": item["passed"], "error": item.get("error"),
                 "dur": round(item.get("host_watchdog", {}).get("measured_s", -1), 2),
                 "timed_out": item.get("guest", {}).get("timed_out"),
                 "bad": bad[:6], "last": lines[-1:], "edges": edges, "ratio": ratio, "odd": odd,
                 "margins": {f"{m[1].lower()}_{m[2]}": [int(m[3]), int(m[4])]
                             for m in map(MARGIN.fullmatch, lines) if m}})
json.dump({"case": case, "hostcpus": hostcpus, "repeat": repeat, "rows": rows,
           "series_error": report.get("series_error")}, open(out, "w"))
print(case, hostcpus, "passed", sum(r["passed"] for r in rows), "of", len(rows))
