"""Diagnostic summary of the hosted margin artefacts (not acceptance)."""
import json, sys, os, re, statistics as st, glob
H = sys.argv[1]
REF = 999_847
def pct(x): return f"{(x / REF - 1) * 100:+.3f}"
out = {}
for case in ("four", "eight", "nine-capacity", "m3-load-two", "m3-load-eight"):
    base = f"{H}/{case}/x/build/k06-margin-{case}"
    r = json.load(open(f"{base}/diagnostic/margin-report.json"))
    rows = r["cases"]
    fails = [(c["iteration"], c.get("error")) for c in rows if not c["passed"]]
    dur = [c["host_watchdog"]["measured_s"] for c in rows if "host_watchdog" in c]
    edges = [c["observed"].get("clock_edges") for c in rows if c.get("observed")]
    edges = [e for e in edges if e]
    worst = {}
    for c in rows:
        for k, (u, l) in (c.get("observed") or {}).get("guest_waits", {}).items():
            if k not in worst or u / l > worst[k][0] / worst[k][1]:
                worst[k] = (u, l)
    top = sorted(worst.items(), key=lambda kv: -kv[1][0] / kv[1][1])[:8]
    # serial-derived: RATIO, clock medians, failing lines
    ratios, raw_med, serial_fail = [], [], []
    for d in sorted(glob.glob(f"{base}/run/*/serial.txt")):
        t = open(d, errors="replace").read().splitlines()
        for l in t:
            if l.startswith("SMP:TIMER:RATIO:"): ratios.append(int(l.rsplit(":", 1)[1]))
        bad = [l for l in t if re.search(r"FAIL|TIMEOUT|STALLED|STUCK|DRIFT|OVERFLOW|PIT_COUNT", l) and not l.startswith("SMP:CLOCK:SAMPLE")]
        if bad: serial_fail.append((os.path.basename(os.path.dirname(d))[:22], bad[:3]))
    print(f"== {case}: passed {sum(c['passed'] for c in rows)}/{len(rows)} report.passed={r['passed']} cpus={rows[0]['cpus']} threads={rows[0]['tcg_threads']}")
    print(f"   fails: {fails[:6]}")
    print(f"   serial fail lines: {serial_fail[:4]}")
    print(f"   duration s min/med/max: {min(dur):.1f}/{st.median(dur):.1f}/{max(dur):.1f} of {rows[0]['host_watchdog']['deadline_s']}")
    if ratios: print(f"   RATIO min/med/max: {min(ratios)}/{int(st.median(ratios))}/{max(ratios)} (band 50000..75000), n={len(ratios)}")
    if edges:
        print(f"   edges keys: {sorted(edges[0])}")
        lost = [e["lost"] for e in edges]; host = [e["host"] for e in edges]; extra = [e["extra"] for e in edges]
        us = [e["median_us"] for e in edges]; own = [e["own_median_us"] for e in edges]; span = [e.get("span_us", 0) for e in edges]
        tick = [e["ticks"] for e in edges]
        print(f"   n={len(edges)} ticks min/max {min(tick)}/{max(tick)}; lost min/med/max {min(lost)}/{st.median(lost)}/{max(lost)}; boots with lost>0: {sum(l > 0 for l in lost)}")
        print(f"   host-charged max {max(host)}; kernel-charged (lost-host) max {max(l - h for l, h in zip(lost, host))}, boots>0: {sum(l - h > 0 for l, h in zip(lost, host))}; extra>0 boots: {sum(x > 0 for x in extra)} max {max(extra)}")
        print(f"   raw median dev % min/med/max: {pct(min(us))}/{pct(st.median(us))}/{pct(max(us))}; boots |raw|>1%: {sum(abs(u / REF - 1) > 0.01 for u in us)}; >0.5%: {sum(abs(u / REF - 1) > 0.005 for u in us)}")
        print(f"   own median dev % min/med/max: {pct(min(own))}/{pct(st.median(own))}/{pct(max(own))}; boots |own|>0.5%: {sum(abs(u / REF - 1) > 0.005 for u in own)}")
        print(f"   span_us max {max(span)} med {st.median(span)}")
    print("   worst margins: " + "; ".join(f"{k} {u}/{l} ({100 * u // l}%)" for k, (u, l) in top))
    nkeys = [len((c.get('observed') or {}).get('guest_waits', {})) for c in rows]
    print(f"   margin keys per boot min/max: {min(nkeys)}/{max(nkeys)}")
