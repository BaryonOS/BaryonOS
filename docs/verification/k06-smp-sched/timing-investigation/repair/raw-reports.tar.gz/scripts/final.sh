#!/bin/bash
# Final verification in the main checkout, 4 host CPUs, one step at a time.
S=<scratch>
cd /home/user/BaryonOS
export NOS_QEMU_MACHINE=pc-q35-8.2
O=$S/final-summary.txt; L=$S/final-logs; mkdir -p $L; : > $O
step() { # name command...
  local name=$1; shift; local t0=$(date +%s)
  "$@" > $L/$name.log 2>&1; local rc=$?
  echo "$name exit=$rc secs=$(( $(date +%s) - t0 )) $(grep -a -E '^Ran [0-9]+ tests|^OK|^FAILED|test result:' $L/$name.log | tr '\n' ' ' | cut -c1-160)" >> $O
}
git rev-parse HEAD >> $O; git status --short | tr '\n' ' ' >> $O; echo >> $O
step fmt cargo fmt --all -- --check
step clippy cargo clippy --locked -p boot-protocol -p smp-lock --all-targets -- -D warnings
step rust-host-tests cargo test --locked -p boot-protocol -p smp-lock
step py-compileall python3 -m compileall -q tools tests userspace/tests experiments/quantum/native experiments/quantum/native/job .agents/skills/os-dev
step py-ci-evidence python3 -B -m unittest discover -s tests -p 'test_ci_evidence*.py'
step py-ci-workflows python3 -B -m unittest discover -s tests -p 'test_ci_workflows.py'
step py-document-session python3 -m unittest discover -s tests -p 'test_document_session_*.py'
step py-volume python3 -m unittest discover -s tests -p 'test_volume_*.py'
step py-system python3 -m unittest discover -s tests -p 'test_system_*.py'
step py-tools-tests python3 -m unittest discover -s tools/tests -p 'test_*.py'
step py-skill-validate python3 .agents/skills/os-dev/scripts/validate_skill.py
step py-skill-tests python3 -m unittest discover -s .agents/skills/os-dev/tests -p 'test_*.py'
for pattern in test_common.py test_preflight.py test_build_paths.py test_guest_harness.py test_m1_artifact_binding.py 'test_m6c_*.py'; do
  step "py-harness-${pattern%%.py}" python3 -B -m unittest discover -s tests -p "$pattern"
done
boot() { # case
  local feature=$(python3 -B -c "import sys; sys.path.insert(0,'tools'); import run_smp; print(run_smp.CASES[sys.argv[1]][0])" $1)
  if [ "$feature" != "$BUILT" ]; then step "build-$feature" python3 -B tools/build.py --kernel-feature $feature; BUILT=$feature; fi
  step "boot-$1" python3 -B tools/run_smp.py --case $1
  echo "   $(grep -a -h -E 'SMP:SYNC:(WAIT_MS|STALLED|TIMEOUT|LOST)|SMP:CLOCK:(EDGES|DRIFT|PIT_COUNT)|SMP:LOCK:STUCK|^M1:' $L/boot-$1.log build/run/smp-$1-*/serial.txt 2>/dev/null | sort -u | tr '\n' ' ' | cut -c1-330)" >> $O
  rm -rf build/run
}
for c in four eight nine-capacity one two-single m3-two lock-stuck sync-stall sync-slow sync-lost-update clock-masked clock-divisor; do boot $c; done
echo done >> $O
