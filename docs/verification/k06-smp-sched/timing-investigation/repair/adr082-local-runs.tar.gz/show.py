import json,sys
for l in open(sys.argv[1]):
    r=json.loads(l); e=r.get('edges') or {}
    print(r['case'],'exit',r['exit'],f"{r['s']}s",'pass' if r.get('passed') else 'FAIL','sync',r.get('sync'),r.get('sync_stall'),'scr',r.get('scratch'),r.get('scratch_stall'),'clk',e.get('lost'),e.get('host'),e.get('median_us'),e.get('own_median_us'),'host_s',r.get('host_s'), (r.get('error') or '')[:160], (r.get('tail') or '')[-240:].replace(chr(10),' | ') if not r.get('passed') else '')
