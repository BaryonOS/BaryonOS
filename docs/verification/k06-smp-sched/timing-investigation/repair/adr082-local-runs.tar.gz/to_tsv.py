"""Write the local ADR-082 boot rows as one TSV (diagnostic evidence)."""
import json, sys
out = open(sys.argv[1], "w")
cols = ["series", "commit", "qemu", "host_cpus", "case", "passed", "failure", "duration_s",
        "sync_ms", "sync_stall_ms", "scratch_ms", "scratch_stall_ms", "lost", "host",
        "median_us", "own_median_us"]
out.write("\t".join(cols) + "\n")
for spec in sys.argv[2:]:
    series, commit, cpus, path = spec.split(",")
    for line in open(path):
        r = json.loads(line); e = r.get("edges") or {}
        v = lambda x, i: "" if not x else str(x[i])
        row = [series, commit, "8.2.2", cpus, r["case"], "1" if r.get("passed") else "0",
               (r.get("error") or "")[:80], str(round(r.get("host_s") or r["s"], 2)),
               v(r.get("sync"), 0), v(r.get("sync_stall"), 0), v(r.get("scratch"), 0),
               v(r.get("scratch_stall"), 0), str(e.get("lost", "")), str(e.get("host", "")),
               str(e.get("median_us", "")), str(e.get("own_median_us", ""))]
        out.write("\t".join(row) + "\n")
