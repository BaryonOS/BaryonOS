#!/usr/bin/env python3
"""Boot chosen K06 cases one at a time; one compact JSON line per boot."""
import json, os, subprocess, sys, time
ROOT = "/home/user/BaryonOS"
sys.path.insert(0, ROOT + "/tools")
from run_smp import CASES
out, prefix, cases = sys.argv[1], sys.argv[2], sys.argv[3:]
for case in cases:
    profile = CASES[case][0]
    env = dict(os.environ, NOS_QEMU_MACHINE="pc-q35-8.2", NOS_BUILD_DIR=f"{ROOT}/build/k06-{profile}")
    built = subprocess.run([sys.executable, "-B", "tools/build.py", "--kernel-feature", profile],
                           cwd=ROOT, env=env, capture_output=True, text=True)
    start = time.time()
    run = subprocess.run(prefix.split() + [sys.executable, "-B", "tools/run_smp.py", "--case", case],
                         cwd=ROOT, env=env, capture_output=True, text=True)
    row = {"case": case, "build": built.returncode, "exit": run.returncode, "s": round(time.time() - start, 1)}
    try:
        report = json.load(open(f"{ROOT}/build/k06-{profile}/smp-report.json"))
        item = report["cases"][-1]
        obs = item.get("observed") or {}
        waits = obs.get("guest_waits") or {}
        row.update(passed=item.get("passed"), error=item.get("error"),
                   sync=waits.get("sync_wait"), sync_stall=waits.get("sync_stall"),
                   scratch=waits.get("scratch_wait"), scratch_stall=waits.get("scratch_stall"),
                   edges=obs.get("clock_edges"), host_s=(item.get("host_watchdog") or {}).get("measured_s"))
    except Exception as exc:  # keep going; the row records it
        row["report_error"] = repr(exc)
    if run.returncode:
        row["tail"] = (run.stdout + run.stderr)[-600:]
    with open(out, "a") as f:
        f.write(json.dumps(row) + "\n")
